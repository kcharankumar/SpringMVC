package com.charan;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/MyData")
public class MyRESTController {
 
    @RequestMapping(value="/{time}", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody List<String> getMyData(
            @PathVariable long time) {
    System.out.println("In the controller.../time..GET");
    
         List<String> lst = new ArrayList<String>();
         lst.add("Charan");
         lst.add("lavanya tripathi...");
         
         return lst;
    
    	
       // return new MyData(1234, "REST GET Call !!!");
    }
 
    @RequestMapping(method = RequestMethod.PUT)
    public @ResponseBody MyData putMyData(
            @RequestBody MyData md) {
 
        return md;
    }
 
    @RequestMapping(method = RequestMethod.POST)
    public @ResponseBody MyData postMyData() {
 
 return new MyData(System.currentTimeMillis(),
            "REST POST Call !!!");
    }
 
    @RequestMapping(value="/{time}", method = RequestMethod.DELETE)
    public @ResponseBody MyData deleteMyData(
            @PathVariable long time) {
 
        return new MyData(time, "REST DELETE Call !!!");
    }
}