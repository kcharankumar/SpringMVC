package com.charan;

public class MyData {
	
	long time;
	String msg;
	public MyData(long time2, String msg1) {
		 time = time2;
		 msg = msg1;
	}
	public long getTime() {
		return time;
	}
	public void setTime(long time) {
		this.time = time;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	

}
